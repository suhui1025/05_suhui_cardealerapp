var brandlist = new Array("Porsche","Volkswagen","Audi","BMW");

var count = 0;

function newClient(){
	var preference = Math.floor((Math.random()*4));
	var time = Math.floor((Math.random()*10000)+1);
	var client = Math.floor((Math.random()*10)+1);
	if(count <5 ) {
		var brandName = brandlist[preference];
		
	$("#clients_queue").append('<div class="client client_'+client+' choice_' + brandName + '"><span class="preference">Client for '+brandlist[preference]+'</span></div>');
		
		count++;
		
		var clients = $("#clients_queue .client");
		var firstClient = clients[0];
		var $firstClient = $(firstClient);
		var clientDragOption = {
									revert : true,
									zIndex : 1
		};
		$firstClient.draggable(clientDragOption);
		console.log($firstClient.html());
	}
		setTimeout(function(){newClient();},time);
}

function makeCarBoxesDroppable() {
	var $carBoxes = $("#porsche .car");
	var options = {
					accept:'.choice_Porsche',
					drop: function(e, ui) {
						var $dropBox = $(this);
						var $dragBox = $(ui.draggable);
						$dropBox.append($dragBox);
						$dragBox.position({of:$dropBox,my:'left top',at:'left top'});
						
						var removeMarginStyle = {
							"margin-top":'0px',
							"margin-bottom":'0px',
							"margin-left":'-3px'
						};
						$dragBox.css(removeMarginStyle);
						count--;
					}
					};
	$carBoxes.droppable(options);
}

$(
	function() {
		makeCarBoxesDroppable();
		newClient();
	}

)
$("document").ready(function(e) {
	newClient();
});
